git clone https://github.com/arashsd/TiGeR

cd TiGeR/cli

chmod +x tiger.sh

chmod 777 auto.sh && sed -i -e 's/\r$//' auto.sh

./tiger.sh install && ./tiger.sh
